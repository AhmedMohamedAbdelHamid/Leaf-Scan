import 'dart:io';
import 'dart:typed_data';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle; // For loading labels.txt
import 'package:image_picker/image_picker.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;

void main() {
  runApp(const PlantAnalyzerApp());
}

class PlantAnalyzerApp extends StatelessWidget {
  const PlantAnalyzerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Plant Disease Analyzer',
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.green[50],
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.green[700],
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green[600],
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            textStyle: const TextStyle(fontSize: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        cardTheme: CardTheme(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          margin: const EdgeInsets.all(10),
        ),
        textTheme: TextTheme(
          titleLarge: TextStyle(color: Colors.green[800], fontWeight: FontWeight.bold),
          bodyMedium: TextStyle(color: Colors.green[700]),
        ),
        progressIndicatorTheme: ProgressIndicatorThemeData(
          color: Colors.green[700],
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  File? _imageFile;
  String _analysisResult = 'No image selected.';
  bool _isLoading = false;
  final ImagePicker _picker = ImagePicker();

  Interpreter? _interpreter;
  List<String> _labels = [];

  // Model input and output details
  late int _inputHeight;
  late int _inputWidth;
  late int _inputChannels;
  late TfLiteType _inputType; // Correctly declared as TfLiteType
  late int _outputSize;
  late TfLiteType _outputType; // Correctly declared as TfLiteType


  @override
  void initState() {
    super.initState();
    _loadLabels();
    _loadModel();
  }

  Future<void> _loadLabels() async {
    try {
      // Assuming labels.txt is in your assets folder and declared in pubspec.yaml
      String labelsData = await rootBundle.loadString('assets/labels.txt');
      _labels = labelsData.split('\n')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
      print("Labels loaded from assets/labels.txt: ${_labels.length} classes");
    } catch (e) {
      print("Error loading labels from assets/labels.txt: $e");
      // Fallback to your placeholder labels if the file isn't found
      _labels = [
        'Apple___Apple_scab',
        'Apple___Black_rot',
        'Apple___Cedar_apple_rust',
        'Apple___healthy',
        'Blueberry___healthy',
        'Cherry_(including_sour)___Powdery_mildew',
        'Cherry_(including_sour)___healthy',
        'Corn_(maize)___Cercospora_leaf_spot_Gray_leaf_spot',
        'Corn_(maize)___Common_rust_',
        'Corn_(maize)___Northern_Leaf_Blight',
        'Corn_(maize)___healthy',
        'Grape___Black_rot',
        'Grape___Esca_(Black_Measles)',
        'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)',
        'Grape___healthy',
        'Orange___Haunglongbing_(Citrus_greening)',
        'Peach___Bacterial_spot',
        'Peach___healthy',
        'Pepper,_bell___Bacterial_spot',
        'Pepper,_bell___healthy',
        'Potato___Early_blight',
        'Potato___Late_blight',
        'Potato___healthy',
        'Raspberry___healthy',
        'Soybean___healthy',
        'Squash___Powdery_mildew',
        'Strawberry___Leaf_scorch',
        'Strawberry___healthy',
        'Tomato___Bacterial_spot',
        'Tomato___Early_blight',
        'Tomato___Late_blight',
        'Tomato___Leaf_Mold',
        'Tomato___Septoria_leaf_spot',
        'Tomato___Spider_mites_Two-spotted_spider_mite',
        'Tomato___Target_Spot',
        'Tomato___Tomato_Yellow_Leaf_Curl_Virus',
        'Tomato___Tomato_mosaic_virus',
        'Tomato___healthy'
      ];
      print("Labels loaded (using hardcoded fallback list): ${_labels.length} classes");
    }
  }

  Future<void> _loadModel() async {
    setState(() {
      _isLoading = true;
      _analysisResult = 'Loading model...';
    });

    try {
      print("Loading TFLite model...");
      _interpreter = await Interpreter.fromAsset('assets/plant_disease_model_cpu.tflite');
      print("Model loaded successfully!");

      // Get input tensor info
      var inputTensor = _interpreter!.getInputTensors()[0];
      var inputShape = inputTensor.shape; // _inputShape is now handled internally, dimensions are extracted
      _inputType = inputTensor.type;

      // Ensure inputShape has at least 4 dimensions (batch, height, width, channels)
      if (inputShape.length != 4) {
        throw Exception("Model input shape is not 4-dimensional (e.g., [1, H, W, 3]). Found: $inputShape");
      }
      _inputHeight = inputShape[1];
      _inputWidth = inputShape[2];
      _inputChannels = inputShape[3];

      // Get output tensor info
      var outputTensors = _interpreter!.getOutputTensors();
      var outputTensor = outputTensors[0];
      var outputShape = outputTensor.shape;
      _outputType = outputTensor.type;

      // Ensure outputShape has 2 dimensions (batch, num_classes)
      if (outputShape.length != 2) {
        throw Exception("Model output shape is not 2-dimensional (e.g., [1, N_CLASSES]). Found: $outputShape");
      }
      _outputSize = outputShape[1];

      print('Model Input: Shape=$inputShape, Type=$_inputType');
      print('Model Output: Shape=$outputShape, Type=$_outputType');
      print('Model expects: ${_inputWidth}x${_inputHeight}x${_inputChannels} image input.');
      print('Model outputs: $_outputSize classes.');
      print('Labels available: ${_labels.length}');

      if (_outputSize != _labels.length) {
        print('WARNING: Number of model output classes (${_outputSize}) does not match number of labels (${_labels.length}). This can cause incorrect predictions!');
      }

      setState(() {
        _analysisResult = 'Model loaded! Ready to analyze images.\n\nModel expects: ${_inputWidth}x${_inputHeight}x${_inputChannels} images\nOutput classes: $_outputSize';
      });

    } catch (e) {
      print("Error loading model: $e");
      setState(() {
        _analysisResult = 'Failed to load model: $e\n\nTroubleshooting:\n• Check assets/plant_disease_model_cpu.tflite exists\n• Verify pubspec.yaml includes the asset\n• Ensure model file is valid TFLite format and its input/output shapes are as expected.';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    if (_isLoading) return;

    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 90, // Reduced quality slightly for faster processing/smaller file size
      );

      if (pickedFile != null) {
        setState(() {
          _imageFile = File(pickedFile.path);
          _analysisResult = 'Image selected. Click "Analyze Plant" to get results.';
        });
      } else {
        setState(() {
          _analysisResult = 'No image selected.';
        });
      }
    } catch (e) {
      setState(() {
        _analysisResult = 'Failed to pick image: $e';
      });
      print("Error picking image: $e");
    }
  }

  Future<void> _analyzeImage() async {
    if (_imageFile == null || _interpreter == null || _labels.isEmpty) {
      setState(() {
        _analysisResult = 'Please select an image, ensure model is loaded, and labels are available.';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _analysisResult = 'Analyzing image...';
    });

    try {
      print("\n=== STARTING IMAGE ANALYSIS ===");

      // Step 1: Load and decode image
      print("Step 1: Loading image...");
      Uint8List imageBytes = await _imageFile!.readAsBytes();
      img.Image? originalImage = img.decodeImage(imageBytes);

      if (originalImage == null) {
        throw Exception("Could not decode image. Try a different image format (JPG/PNG).");
      }

      print("Original image: ${originalImage.width}x${originalImage.height}");

      // Step 2: Resize image
      print("Step 2: Resizing to ${_inputWidth}x${_inputHeight}...");
      img.Image resizedImage = img.copyResize(
        originalImage,
        width: _inputWidth,
        height: _inputHeight,
        interpolation: img.Interpolation.linear, // Or bicubic
      );
      print("Resized successfully: ${resizedImage.width}x${resizedImage.height}");

      // Step 3: Prepare input for the model based on its expected type
      var input = _prepareModelInput(resizedImage);
      print("Step 3: Image preprocessed for model. Input type: ${input.runtimeType}");

      // Step 4: Prepare output tensor
      // Output buffer, assuming batch size 1 and _outputSize classes
      var outputBuffer = List.filled(1 * _outputSize, 0.0);
      var output = [outputBuffer.reshape([1, _outputSize])]; // Reshape to [1, num_classes] for run method

      print("Step 4: Running inference...");
      // The `run` method expects `Object input` and `Object output`.
      // For single input/output models, it's typically `List<Object>` for input
      // and `List<List<double>>` or similar for output.
      _interpreter!.run(input, output);
      print("Inference complete.");

      // Step 5: Process results
      List<double> rawScores = (output[0] as List).cast<double>(); // Ensure it's List<double>
      print("Raw output (first 5): ${rawScores.take(5).map((e) => e.toStringAsFixed(4)).toList()}");

      // Apply softmax if the model output is logits (raw scores)
      // If your model already outputs probabilities (e.g., if it has a softmax layer), skip this.
      List<double> probabilities = _applySoftmax(rawScores);
      print("Probabilities (first 5): ${probabilities.take(5).map((e) => e.toStringAsFixed(4)).toList()}");

      // Find best prediction
      double maxProb = probabilities.reduce(math.max);
      int maxIndex = probabilities.indexOf(maxProb);

      String predictedLabel = maxIndex < _labels.length ? _labels[maxIndex] : "Unknown class $maxIndex";
      double confidence = maxProb * 100;

      print("Prediction: $predictedLabel (${confidence.toStringAsFixed(1)}%)");

      // Show top 3 predictions
      List<MapEntry<int, double>> sortedResults = [];
      for (int i = 0; i < probabilities.length; i++) {
        sortedResults.add(MapEntry(i, probabilities[i]));
      }
      sortedResults.sort((a, b) => b.value.compareTo(a.value));

      String resultText = "🔍 Analysis Complete!\n\n";
      resultText += "🏆 Top Prediction:\n";
      resultText += "${sortedResults[0].key < _labels.length ? _labels[sortedResults[0].key] : 'Class ${sortedResults[0].key}'}\n";
      resultText += "Confidence: ${(sortedResults[0].value * 100).toStringAsFixed(1)}%\n\n";

      if (sortedResults.length > 1) {
        resultText += "📊 Other possibilities:\n";
        for (int i = 1; i < math.min(3, sortedResults.length); i++) {
          String label = sortedResults[i].key < _labels.length ? _labels[sortedResults[i].key] : 'Class ${sortedResults[i].key}';
          resultText += "• $label: ${(sortedResults[i].value * 100).toStringAsFixed(1)}%\n";
        }
      }

      setState(() {
        _analysisResult = resultText;
      });

      print("=== ANALYSIS COMPLETED SUCCESSFULLY ===\n");

    } catch (e, stackTrace) {
      print("ANALYSIS FAILED: $e\n$stackTrace");
      setState(() {
        _analysisResult = 'Analysis failed: $e\n\nSuggestions:\n• Try a different image\n• Ensure image is clear and well-lit\n• Restart the app\n• Check model compatibility and input data type.';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }


  // Universal preprocessing function
  Object _prepareModelInput(img.Image image) {
    if (_inputType == TfLiteType.float32) {
      // Create a 1D Float32List
      Float32List inputBytes = Float32List(_inputHeight * _inputWidth * _inputChannels);
      int pixelIndex = 0;
      for (int y = 0; y < _inputHeight; y++) {
        for (int x = 0; x < _inputWidth; x++) {
          final pixel = image.getPixel(x, y);

          // IMPORTANT: Adjust this normalization based on your model's training!
          // Common normalizations:
          // 1. [0, 1] range: e.g., (img.getRed(pixel) / 255.0)
          // 2. [-1, 1] range: e.g., (img.getRed(pixel) - 127.5) / 127.5
          // 3. ImageNet mean/std: e.g., (img.getRed(pixel) / 255.0 - mean) / std

          // Assuming [0,1] normalization for now, this is most common for custom models.
          // IF YOUR MODEL WAS TRAINED WITH IMAGENET MEAN/STD, USE METHOD 3 LOGIC.
          // IF YOUR MODEL WAS TRAINED WITH [-1, 1], USE THAT LOGIC.
          inputBytes[pixelIndex++] = img.getRed(pixel) / 255.0;
          inputBytes[pixelIndex++] = img.getGreen(pixel) / 255.0;
          inputBytes[pixelIndex++] = img.getBlue(pixel) / 255.0;
        }
      }
      // Wrap the 1D Float32List in a List for the interpreter.run method
      // This will be interpreted as a [1, H, W, C] tensor by the interpreter
      // if the model's input shape matches and type is float32.
      return [inputBytes.buffer]; // Pass the ByteBuffer
    } else if (_inputType == TfLiteType.uint8) {
      // Create a 1D Uint8List
      Uint8List inputBytes = Uint8List(_inputHeight * _inputWidth * _inputChannels);
      int pixelIndex = 0;
      for (int y = 0; y < _inputHeight; y++) {
        for (int x = 0; x < _inputWidth; x++) {
          final pixel = image.getPixel(x, y);
          // For Uint8, just use the raw pixel values (0-255)
          inputBytes[pixelIndex++] = img.getRed(pixel);
          inputBytes[pixelIndex++] = img.getGreen(pixel);
          inputBytes[pixelIndex++] = img.getBlue(pixel);
        }
      }
      return [inputBytes.buffer]; // Pass the ByteBuffer
    } else {
      throw Exception("Unsupported input TfLiteType: $_inputType. Please check your model.");
    }
  }


  // Softmax function
  List<double> _applySoftmax(List<double> input) {
    if (input.isEmpty) return [];
    double maxVal = input.reduce(math.max);
    List<double> exp = input.map((x) => math.exp(x - maxVal)).toList();
    double sum = exp.reduce((a, b) => a + b);
    if (sum == 0) return List.filled(input.length, 0.0); // Avoid division by zero
    return exp.map((x) => x / sum).toList();
  }

  @override
  void dispose() {
    _interpreter?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Plant Disease Analyzer'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                // Loading indicator for model
                if (_isLoading && _analysisResult.contains('Loading model'))
                  Column(
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 15),
                      Text(_analysisResult, textAlign: TextAlign.center),
                      const SizedBox(height: 20),
                    ],
                  ),

                // Image upload card
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        Text(
                          'Upload Plant Image',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 20),
                        _imageFile == null
                            ? Container(
                          height: 200,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.green[100],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.green[300]!),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.image_search,
                                size: 60,
                                color: Colors.green[400],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'No image selected',
                                style: TextStyle(color: Colors.green[600]),
                              ),
                            ],
                          ),
                        )
                            : ClipRRect(
                          borderRadius: BorderRadius.circular(12.0),
                          child: Image.file(
                            _imageFile!,
                            height: 250,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            ElevatedButton.icon(
                              onPressed: _isLoading ? null : () => _pickImage(ImageSource.camera),
                              icon: const Icon(Icons.camera_alt),
                              label: const Text('Camera'),
                            ),
                            ElevatedButton.icon(
                              onPressed: _isLoading ? null : () => _pickImage(ImageSource.gallery),
                              icon: const Icon(Icons.photo_library),
                              label: const Text('Gallery'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // Analyze button
                if (_imageFile != null && _interpreter != null)
                  ElevatedButton.icon(
                    onPressed: _isLoading ? null : _analyzeImage,
                    icon: _isLoading
                        ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                        : const Icon(Icons.science_outlined),
                    label: Text(_isLoading ? 'Analyzing...' : 'Analyze Plant'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange[600],
                      padding: const EdgeInsets.symmetric(vertical: 18),
                    ),
                  ),

                const SizedBox(height: 30),

                // Results card
                Card(
                  color: Colors.green[100],
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        Text(
                          'Analysis Result',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 18),
                        ),
                        const SizedBox(height: 15),
                        Text(
                          _analysisResult,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}